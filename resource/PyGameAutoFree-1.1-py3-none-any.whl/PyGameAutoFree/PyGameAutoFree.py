# !/usr/bin/env python
# -*-coding:utf-8 -*-


def err_print(*args):
    pass


def debug_print(*args):
    pass


def sleep(times):
    pass


def Point(x, y):
    pass


def toDict(*args):
    pass


class Dm:
    def register(self):
        pass

    def Create(self):
        pass

    def Ver(self):
        pass

    def RegisterVip(self, *args):
        pass

    def SetShowErrorMsg(self, *args):
        pass

    def SetPath(self, *args):
        pass

    def IsBind(self, *args):
        pass

    def SetDict(self, *args):
        pass

    def EnumWindow(self, *args):
        pass

    def GetWindow(self, *args):
        pass

    def MoveWindow(self, *args):
        pass

    def BindWindow(self, *args):
        pass

    def BindWindowEx(self, *args):
        pass

    def SetWindowState(self, *args):
        pass

    def UnBindWindow(self):
        pass

    def FetchWord(self, *args):
        pass

    def IsDisplayDead(self, *args):
        pass

    def FindPic(self, *args):
        pass

    def CmpColor(self, *args):
        pass

    def FindColor(self, *args):
        pass

    def FindMultiColor(self, *args):
        pass

    def KeyPress(self, *args):
        pass

    def MoveTo(self, *args):
        pass

    def LeftClick(self):
        pass

    def LeftDown(self):
        pass

    def LeftUp(self):
        pass

    def SendString(self, *args):
        pass

    def FindStrFast(self, *args):
        pass

    def Ocr(self, *args):
        pass

    def slide(self, *args):
        pass


class Custom:
    def __init__(self):
        self.dm = Dm()
        self.hwnd = None
        self.thread = Thread()


class Action:
    def __init__(self, *args):
        pass

    def click(self, *args):
        return self

    def sleep(self, *args):
        return self

    def f(self, *args):
        return self

    def after(self, *args):
        return self


class PyGameAuto:
    @classmethod
    def gl_init(cls, reg_code, ver_info):
        return Dm()

    @classmethod
    def get_path(cls, *args):
        pass

    def set_win(self, *args):
        return self

    def set_hwnd(self, *args):
        return self

    def set_path(self, *args):
        return self

    def set_dict(self, *args):
        return self

    def run(self, *args):
        pass


gl_info = Custom()


class Thread:
    handle = None

    def __init__(self, target=None, args=(), kwargs=None):
        pass

    def start(self):
        pass

    def stop(self):
        pass

    def pause(self):
        pass

    def resume(self):
        pass


class UI:
    def __init__(self, *args):
        pass

    def clicked(self, *args):
        pass


def UINew(*args):
    pass


def UIShow(*args):
    pass


class UIHLayout:
    def __init__(self, *args):
        pass


class UIVLayout:
    def __init__(self, *args):
        pass


class UIButton:
    def __init__(self, *args):
        pass


class UIEdit:
    def __init__(self, *args):
        pass


class UITextArea:
    def __init__(self, *args):
        pass

