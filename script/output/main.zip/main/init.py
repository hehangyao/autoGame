# -*-coding:utf-8 -*-
root = {
    "menu": [
        {
            "text": "鉴定背包",
            "valueName": "authenticate"
        },
        {
            "text": "日常副本",
            "valueName": "branch"
        },
        {
            "text": "游戏设置",
            "valueName": "options"
        }
    ]
}
